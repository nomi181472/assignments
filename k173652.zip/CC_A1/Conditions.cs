﻿namespace CC_A1
{
    public class Conditions
    {
        public string condition { get; set; }
        public string action { get; set; }

    }
}
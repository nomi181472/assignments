﻿namespace CC_A1
{
    public class Parameters
    {
        
        public string parameter { get; set; }
        public string type { get; set; }
    }
}
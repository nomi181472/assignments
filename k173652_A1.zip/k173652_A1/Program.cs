﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace CC_A1
{
    
    

   

    
    class Program
    {
        

        static void Main(string[] args)
        {
            try
            {
                string file_name = @"fibonacci.json";
                string path = @"C:\Users\noman\source\repos\Assignment1\CC_A1\" + file_name;
                CodeGenerator cg = new CodeGenerator();
                cg.readFile(path);
                // string jsonString = File.ReadAllText(fileName);
                string code = cg.generateCode();

                Console.WriteLine(code);
                Console.WriteLine(cg.error);
                File.WriteAllText(@"C:\Users\noman\source\repos\Assignment1\CC_A1\" + file_name.Substring(0,file_name.Length-5) + "-Output.cpp", code);
            }
            catch (Exception err)
            {
                Console.WriteLine(err);
            }




        }
    }
}
